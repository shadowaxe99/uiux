from src.agent_interaction import AgentInteraction

if __name__ == '__main__':
    ai = AgentInteraction()
    ai.initialize_project('Test Project', 'Test Objectives')