# Deployment Guide

## Prerequisites

- Python 3

## Steps

1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Run the main.py file to start the application.

   ```bash
   python3 main.py
   ```

The application should now be running and ready for use.