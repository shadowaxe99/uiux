class ChatInterface:
    def __init__(self):
        pass

    def start_chat(self, project_name):
        pass

    def add_feedback(self, project_name, feedback):
        pass

    def search_feedback(self, search_query):
        pass